
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace CloudQA_Automation.Tests
{
    public class AutomationPracticeFormTests
    {
        private IWebDriver driver;
        private string baseUrl = "https://app.cloudqa.io/home/AutomationPracticeForm";

        [SetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(baseUrl);
        }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }

        [Test]
        public void Test_FirstName_LastName_Email()
        {
            var firstName = driver.FindElement(By.XPath("//input[contains(@placeholder,'First') or contains(@aria-label,'First')]"));
            firstName.Clear();
            firstName.SendKeys("Sujal");

            var lastName = driver.FindElement(By.XPath("//input[contains(@placeholder,'Last') or contains(@aria-label,'Last')]"));
            lastName.Clear();
            lastName.SendKeys("Patil");

            var email = driver.FindElement(By.XPath("//input[contains(@placeholder,'Email') or @type='email']"));
            email.Clear();
            email.SendKeys("sujal@example.com");

            Assert.AreEqual("Sujal", firstName.GetAttribute("value"));
            Assert.AreEqual("Patil", lastName.GetAttribute("value"));
            Assert.AreEqual("sujal@example.com", email.GetAttribute("value"));
        }
    }
}
