
# CloudQA Automation – Selenium C# Tests

Automated test cases for the CloudQA Automation Practice Form.

## Automated Fields
- First Name  
- Last Name  
- Email  

## Tools Used
- C#  
- Selenium WebDriver  
- NUnit  
- ChromeDriver  

## How to Run

```
dotnet restore
dotnet test
```

## Notes
Locators are robust and dynamic to handle HTML changes.

Author: Sujal Patil
